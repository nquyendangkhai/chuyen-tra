# 🍵 Chuyện Trà — Hệ Thống Toàn Diện Frontend + Backend + Database

Chào mừng bạn đến với dự án **Chuyện Trà**. Dự án đã được hoàn thiện đầy đủ hệ thống **Backend REST API** và **Cơ sở dữ liệu (Database)** để lưu trữ và quản lý toàn bộ dữ liệu người dùng, bài viết, đơn hàng và lịch hẹn thưởng trà.

---

## 🌟 1. Cấu Trúc Dự Án

```
chuyen-tra-project/
├── server.js              # Máy chủ Express REST API (Cổng 5000)
├── db.js                  # Engine Cơ sở dữ liệu chuẩn ACID với Atomic File Write
├── data/
│   └── database.json      # File lưu trữ dữ liệu vĩnh viễn (Người dùng, Đơn hàng, Bài viết, Lịch hẹn)
├── public/
│   ├── index.html         # Giao diện chính website Chuyện Trà (đồng bộ API)
│   └── admin.html         # Bảng điều khiển Quản trị viên (Admin Dashboard)
├── package.json           # Danh sách thư viện (Express, Cors)
└── start.bat              # File chạy nhanh 1-click trên Windows
```

---

## 🚀 2. Cách Khởi Động Máy Chủ

### Cách 1: Click đúp vào file `start.bat`
Chỉ cần nhấp đúp vào [start.bat](file:///C:/Users/nquye/.gemini/antigravity/scratch/chuyen-tra-project/start.bat) trong thư mục dự án.

### Cách 2: Sử dụng dòng lệnh Terminal / PowerShell
```powershell
cd C:\Users\nquye\.gemini\antigravity\scratch\chuyen-tra-project
node server.js
```

---

## 🌐 3. Các Đường Dẫn Truy Cập

- **Website Chuyện Trà:** [http://localhost:5000](http://localhost:5000)
- **Bảng Quản Trị Hệ Thống (Admin):** [http://localhost:5000/admin](http://localhost:5000/admin)
- **Kiểm Tra Trạng Thái Database:** [http://localhost:5000/api/status](http://localhost:5000/api/status)

---

## 👑 4. Tài Khoản Quản Trị & Trà Hữu Có Sẵn (Đã Seed Sẵn Vào DB)

| Loại Tài Khoản | Họ Tên | Email | Mật Khẩu | Quyền Hạn |
| :--- | :--- | :--- | :--- | :--- |
| **Quản Trị Viên (Admin)** | Trà Sư Quản Trị | `admin@chuyentra.vn` | `admin123` | Toàn quyền quản trị hệ thống |
| **Trà Hữu Mẫu A** | Trà hữu Đăng Khải | `dangkhai@chuyentra.vn` | `123456` | Người dùng tiêu chuẩn |
| **Trà Hữu Mẫu B** | Trà hữu Thanh Tâm | `thanhtam@chuyentra.vn` | `123456` | Người dùng tiêu chuẩn |

---

## 🛠️ 5. Danh Sách API Backend Đã Xây Dựng

### Quản lý Người Dùng (Users & Auth):
- `POST /api/auth/register`: Đăng ký tài khoản mới (tên, email, danh hiệu, mật khẩu).
- `POST /api/auth/login`: Đăng nhập, kiểm tra mật khẩu đã hash.
- `GET /api/users`: Lấy danh sách toàn bộ người dùng trong hệ thống.
- `GET /api/users/:id`: Lấy chi tiết thông tin 1 người dùng.
- `PUT /api/users/:id`: Cập nhật thông tin tài khoản (số điện thoại, địa chỉ, danh hiệu).
- `DELETE /api/users/:id`: Xóa tài khoản người dùng khỏi cơ sở dữ liệu.

### Quản lý Diễn Đàn (Forum):
- `GET /api/forum/threads`: Lấy danh sách chủ đề thảo luận (lọc theo danh mục).
- `POST /api/forum/threads`: Tạo bài viết mới.
- `POST /api/forum/threads/:id/replies`: Thêm bình luận/phản hồi vào bài viết.
- `POST /api/forum/threads/:id/like`: Thả tim bài viết.
- `DELETE /api/forum/threads/:id`: Xóa bài viết.

### Quản lý Đơn Hàng (Orders):
- `GET /api/orders`: Lấy danh sách đơn hàng (lọc theo email người mua).
- `POST /api/orders`: Lưu đơn đặt hàng mới từ giỏ hàng.
- `PUT /api/orders/:id/status`: Cập nhật trạng thái giao hàng (Chờ duyệt, Đang vận chuyển, Đã hoàn thành, Đã hủy).

### Quản lý Lịch Hẹn (Bookings):
- `GET /api/bookings`: Xem danh sách khách đặt bàn thưởng trà.
- `POST /api/bookings`: Khách gửi yêu cầu đặt lịch hẹn.
- `PUT /api/bookings/:id/status`: Xác nhận lịch hẹn.
