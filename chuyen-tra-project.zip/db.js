/**
 * db.js — Bộ cơ sở dữ liệu JSON File-based chuẩn ACID cho Chuyện Trà
 * Tự động tạo file, seed dữ liệu mẫu, ghi file an toàn (Atomic File Write)
 * Đảm bảo dữ liệu người dùng, bài viết, đơn hàng, lịch hẹn không bao giờ bị mất!
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_FILE = path.join(__dirname, 'data', 'database.json');
const TMP_FILE = path.join(__dirname, 'data', 'database.json.tmp');

function hashPassword(password) {
    if (!password) return '';
    return crypto.createHash('sha256').update(String(password)).digest('hex');
}

const INITIAL_USERS = [
    {
        id: 'user_admin',
        name: 'Trà Sư Quản Trị (Admin)',
        email: 'admin@chuyentra.vn',
        badge: 'Chủ Trà Thất',
        role: 'admin',
        passwordHash: hashPassword('admin123'),
        phone: '0988 888 888',
        address: 'Số 12 Tràng Thi, Hoàn Kiếm, Hà Nội',
        createdAt: 1730000000000,
        memberSince: 'Tháng 01, 2025'
    },
    {
        id: 'user_dangkhai',
        name: 'Trà hữu Đăng Khải',
        email: 'dangkhai@chuyentra.vn',
        badge: 'Trà Hữu Tri Âm',
        role: 'user',
        passwordHash: hashPassword('123456'),
        phone: '0912 345 678',
        address: 'Quận Ba Đình, Hà Nội',
        createdAt: 1730000000000,
        memberSince: 'Tháng 03, 2025'
    },
    {
        id: 'user_thanhtam',
        name: 'Trà hữu Thanh Tâm',
        email: 'thanhtam@chuyentra.vn',
        badge: 'Sưu Tầm Shan Tuyết',
        role: 'user',
        passwordHash: hashPassword('123456'),
        phone: '0977 123 456',
        address: 'Quận Cầu Giấy, Hà Nội',
        createdAt: 1730100000000,
        memberSince: 'Tháng 06, 2025'
    }
];

const INITIAL_FORUM_THREADS = [
    {
        id: 'seed_thread_1',
        title: 'Nhật ký 6 tháng dưỡng ấm Tây Thi Chu Nê Đại Hồng Bào với Hồng Trà Tà Xùa',
        category: 'Ấm Tử Sa & Trà Cụ',
        authorName: 'Trà Sư Lâm Đình',
        authorEmail: 'lamdinh@chuyentra.vn',
        authorBadge: 'Trà Sư Chuyện Trà',
        createdAt: Date.now() - 3600000 * 5,
        views: 642,
        likes: 18,
        pinned: true,
        content: 'Chào các vị trà hữu, hôm nay nhân tiết trời Hà Nội mát mẻ, mình chụp lại chiếc ấm Tây Thi Chu Nê 180ml sau đúng 6 tháng chỉ chuyên dùng pha Hồng Trà Cổ Thụ Tà Xùa. Lớp bao tương đã lên ánh ngọc rất dịu mắt. Bí quyết lớn nhất là luôn tráng ấm bằng nước sôi và để khô ráo ngay sau mỗi buổi trà.',
        replies: [
            {
                id: 'r_101',
                authorName: 'Trà hữu Đăng Khải',
                authorEmail: 'dangkhai@chuyentra.vn',
                authorBadge: 'Trà Hữu Tri Âm',
                content: 'Nước da ấm lên nhuận quá bác Lâm Đình ơi! Bác có dùng chổi tưới nước trà bên ngoài khi pha không ạ?',
                createdAt: Date.now() - 3600000 * 3
            },
            {
                id: 'r_102',
                authorName: 'Trà Sư Lâm Đình',
                authorEmail: 'lamdinh@chuyentra.vn',
                authorBadge: 'Trà Sư Chuyện Trà',
                content: 'Mình chỉ tưới nhẹ nước tráng trà tuần đầu lên thân ấm rồi dùng khăn vải mộc thấm khô đều bạn nhé.',
                createdAt: Date.now() - 3600000 * 2
            }
        ]
    },
    {
        id: 'seed_thread_2',
        title: 'Cảm nhận Bạch Trà Mẫu Đơn Tây Côn Lĩnh vụ Xuân 2026 vừa mở hũ',
        category: 'Thưởng Trà Cổ Thụ',
        authorName: 'Trà hữu Thanh Tâm',
        authorEmail: 'thanhtam@chuyentra.vn',
        authorBadge: 'Sưu Tầm Shan Tuyết',
        createdAt: Date.now() - 3600000 * 8,
        views: 418,
        likes: 12,
        pinned: false,
        content: 'Sáng nay mình vừa mở hũ Bạch Trà Mẫu Đơn vụ Xuân 2026 để đối ẩm. Hương hoa rừng và mật non thanh khiết ngay từ tuần nước đầu tiên ở 86°C, uống đến tuần nước thứ 8 vẫn ngọt sâu nơi cuống họng.',
        replies: [
            {
                id: 'r_201',
                authorName: 'Trà hữu Đăng Khải',
                authorEmail: 'dangkhai@chuyentra.vn',
                authorBadge: 'Trà Hữu Tri Âm',
                content: 'Bạch trà cất giữ thêm 1–2 năm trong hũ gốm kín thì hương mật càng đượm hơn nữa bác ạ.',
                createdAt: Date.now() - 3600000 * 4
            }
        ]
    },
    {
        id: 'seed_thread_3',
        title: 'Chia sẻ các nguồn nước đóng chai tại Việt Nam có TDS chuẩn nhất để pha Lục Trà',
        category: 'Kỹ Thuật Pha Trà',
        authorName: 'Hoàng Anh',
        authorEmail: 'hoanganh@chuyentra.vn',
        authorBadge: 'Người Yêu Ấm Tử Sa',
        createdAt: Date.now() - 3600000 * 14,
        views: 530,
        likes: 9,
        pinned: false,
        content: 'Mình đã dùng bút đo TDS và pha thử cùng 5g Lục Trà Suối Giàng ở 82°C. Nước suối tự nhiên có TDS khoảng 38–45 ppm cho sắc nước trong xanh và hậu ngọt rõ rệt hơn hẳn nước lọc RO tinh khiết.',
        replies: []
    },
    {
        id: 'seed_thread_4',
        title: 'Cách phân biệt đất Chu Nê nguyên khoáng Hoàng Long Sơn và đất pha oxit sắt',
        category: 'Ấm Tử Sa & Trà Cụ',
        authorName: 'Trà hữu Đăng Khải',
        authorEmail: 'dangkhai@chuyentra.vn',
        authorBadge: 'Trà Hữu Tri Âm',
        createdAt: Date.now() - 3600000 * 20,
        views: 389,
        likes: 15,
        pinned: false,
        content: 'Khi quan sát dưới ánh sáng tự nhiên, Chu Nê nguyên khoáng luôn có những nếp nhăn vi mô (vân vỏ lê) và hạt cát kim sa ẩn dưới lớp da ấm, không bao giờ bóng gương phẳng lì như ấm pha hóa chất.',
        replies: []
    },
    {
        id: 'seed_thread_5',
        title: 'Góc bàn trà nhỏ bên cửa sổ — Nơi mình tìm lại sự tĩnh lặng mỗi sáng',
        category: 'Góc Trà Hữu',
        authorName: 'An Nhiên',
        authorEmail: 'annhien@chuyentra.vn',
        authorBadge: 'Trà Hữu Tri Âm',
        createdAt: Date.now() - 3600000 * 28,
        views: 495,
        likes: 21,
        pinned: false,
        content: 'Không cần phòng trà lớn, mình chỉ đặt một chiếc khay gỗ hương 60cm bên bệ cửa sổ đón nắng sớm, một chiếc ấm nhỏ 160ml và hai chén sứ trắng. Mời các trà hữu cùng chia sẻ không gian thưởng trà tại gia nhé!',
        replies: []
    }
];

class Database {
    constructor() {
        this.data = {
            users: [],
            threads: [],
            orders: [],
            bookings: [],
            newsletter: []
        };
        this.init();
    }

    init() {
        const dir = path.dirname(DB_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        if (fs.existsSync(DB_FILE)) {
            try {
                const raw = fs.readFileSync(DB_FILE, 'utf8');
                this.data = JSON.parse(raw);
                if (!this.data.users || this.data.users.length === 0) {
                    this.data.users = [...INITIAL_USERS];
                }
                if (!this.data.threads || this.data.threads.length === 0) {
                    this.data.threads = [...INITIAL_FORUM_THREADS];
                }
                if (!this.data.orders) this.data.orders = [];
                if (!this.data.bookings) this.data.bookings = [];
                if (!this.data.newsletter) this.data.newsletter = [];
                this.save();
            } catch (err) {
                console.error('Lỗi khi đọc file database.json, đang phục hồi:', err);
                this.seedInitial();
            }
        } else {
            this.seedInitial();
        }
    }

    seedInitial() {
        this.data = {
            users: [...INITIAL_USERS],
            threads: [...INITIAL_FORUM_THREADS],
            orders: [
                {
                    id: 'order_seed_1',
                    customerName: 'Trà hữu Đăng Khải',
                    customerPhone: '0912 345 678',
                    customerAddress: 'Số 15 phố Phan Đình Phùng, Ba Đình, Hà Nội',
                    notes: 'Giao trong giờ hành chính, đóng gói chống sốc cho ấm tử sa',
                    paymentMethod: 'cod',
                    items: [
                        {
                            id: 1,
                            name: 'Bạch Trà Mẫu Đơn Cổ Thụ Tây Côn Lĩnh',
                            price: 680000,
                            qty: 1,
                            image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=900&q=80'
                        },
                        {
                            id: 2,
                            name: 'Ấm Tử Sa Tây Thi Chu Nê Đại Hồng Bào',
                            price: 2850000,
                            qty: 1,
                            image: 'https://images.unsplash.com/photo-1563822249548-9a72b6353cd1?auto=format&fit=crop&w=900&q=80'
                        }
                    ],
                    total: 3530000,
                    status: 'Đang vận chuyển',
                    userEmail: 'dangkhai@chuyentra.vn',
                    createdAt: Date.now() - 3600000 * 24
                }
            ],
            bookings: [
                {
                    id: 'booking_seed_1',
                    name: 'Trà hữu Thanh Tâm',
                    phone: '0977 123 456',
                    date: new Date(Date.now() + 86400000).toISOString().split('T')[0],
                    timeSlot: '09:00 - 11:00',
                    note: 'Bàn cạnh cửa sổ nhìn ra vườn trúc, thử phẩm Bạch Trà vụ Xuân',
                    contactType: 'Đặt lịch ghé Trà Thất',
                    userEmail: 'thanhtam@chuyentra.vn',
                    status: 'Đã xác nhận',
                    createdAt: Date.now() - 3600000 * 6
                }
            ],
            newsletter: [
                { id: 'nl_1', email: 'khachquy@gmail.com', createdAt: Date.now() - 86400000 }
            ]
        };
        this.save();
    }

    save() {
        try {
            const json = JSON.stringify(this.data, null, 2);
            fs.writeFileSync(TMP_FILE, json, 'utf8');
            fs.renameSync(TMP_FILE, DB_FILE);
            return true;
        } catch (err) {
            console.error('Lỗi khi ghi dữ liệu database:', err);
            return false;
        }
    }

    // ==========================================
    // USER METHODS
    // ==========================================
    getAllUsers() {
        return this.data.users.map(({ passwordHash, ...safeUser }) => safeUser);
    }

    findUserByEmail(email) {
        if (!email) return null;
        return this.data.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase()) || null;
    }

    findUserById(id) {
        return this.data.users.find(u => u.id === id) || null;
    }

    createUser({ name, email, badge, password, phone, address, role }) {
        const cleanEmail = email.trim().toLowerCase();
        if (this.findUserByEmail(cleanEmail)) {
            throw new Error('Email này đã được đăng ký tài khoản');
        }

        const dateNow = new Date();
        const monthNames = ['Tháng 01', 'Tháng 02', 'Tháng 03', 'Tháng 04', 'Tháng 05', 'Tháng 06', 'Tháng 07', 'Tháng 08', 'Tháng 09', 'Tháng 10', 'Tháng 11', 'Tháng 12'];
        const memberSince = `${monthNames[dateNow.getMonth()]}, ${dateNow.getFullYear()}`;

        const newUser = {
            id: 'user_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
            name: name.trim(),
            email: cleanEmail,
            badge: badge || 'Trà Hữu Tri Âm',
            role: role || 'user',
            passwordHash: hashPassword(password || '123456'),
            phone: phone || '',
            address: address || '',
            createdAt: Date.now(),
            memberSince
        };

        this.data.users.push(newUser);
        this.save();

        const { passwordHash: _, ...safeUser } = newUser;
        return safeUser;
    }

    verifyUser(email, password) {
        const user = this.findUserByEmail(email);
        if (!user) return null;
        const hashed = hashPassword(password);
        if (user.passwordHash === hashed || user.passwordHash === password) {
            const { passwordHash: _, ...safeUser } = user;
            return safeUser;
        }
        return null;
    }

    updateUser(id, updates) {
        const index = this.data.users.findIndex(u => u.id === id || u.email.toLowerCase() === (updates.email || '').toLowerCase());
        if (index === -1) {
            throw new Error('Không tìm thấy người dùng');
        }

        const current = this.data.users[index];
        if (updates.name) current.name = updates.name.trim();
        if (updates.badge) current.badge = updates.badge;
        if (updates.phone !== undefined) current.phone = updates.phone;
        if (updates.address !== undefined) current.address = updates.address;
        if (updates.password) current.passwordHash = hashPassword(updates.password);
        if (updates.role) current.role = updates.role;
        current.updatedAt = Date.now();

        this.save();
        const { passwordHash: _, ...safeUser } = current;
        return safeUser;
    }

    deleteUser(id) {
        const index = this.data.users.findIndex(u => u.id === id);
        if (index === -1) return false;
        this.data.users.splice(index, 1);
        this.save();
        return true;
    }

    // ==========================================
    // FORUM THREADS & REPLIES
    // ==========================================
    getAllThreads(category = 'all') {
        let list = [...this.data.threads];
        if (category && category !== 'all') {
            list = list.filter(t => t.category === category);
        }
        return list.sort((a, b) => {
            if (Boolean(b.pinned) !== Boolean(a.pinned)) return b.pinned ? 1 : -1;
            return (b.createdAt || 0) - (a.createdAt || 0);
        });
    }

    getThreadById(id) {
        const thread = this.data.threads.find(t => String(t.id) === String(id));
        if (thread) {
            thread.views = (thread.views || 0) + 1;
            this.save();
        }
        return thread || null;
    }

    createThread({ title, category, content, authorName, authorEmail, authorBadge }) {
        const newThread = {
            id: 'thread_' + Date.now(),
            title: title.trim(),
            category: category || 'Góc Trà Hữu',
            content: content.trim(),
            authorName: authorName || 'Trà hữu Khuyết Danh',
            authorEmail: authorEmail || 'guest@chuyentra.vn',
            authorBadge: authorBadge || 'Trà Hữu Tri Âm',
            createdAt: Date.now(),
            views: 1,
            likes: 0,
            pinned: false,
            replies: []
        };
        this.data.threads.unshift(newThread);
        this.save();
        return newThread;
    }

    addReply(threadId, { authorName, authorEmail, authorBadge, content }) {
        const thread = this.data.threads.find(t => String(t.id) === String(threadId));
        if (!thread) throw new Error('Không tìm thấy bài viết');
        if (!thread.replies) thread.replies = [];

        const newReply = {
            id: 'r_' + Date.now(),
            authorName: authorName || 'Trà hữu',
            authorEmail: authorEmail || 'guest@chuyentra.vn',
            authorBadge: authorBadge || 'Trà Hữu Tri Âm',
            content: content.trim(),
            createdAt: Date.now()
        };

        thread.replies.push(newReply);
        this.save();
        return { thread, reply: newReply };
    }

    toggleLike(threadId) {
        const thread = this.data.threads.find(t => String(t.id) === String(threadId));
        if (!thread) throw new Error('Không tìm thấy bài viết');
        thread.likes = (thread.likes || 0) + 1;
        this.save();
        return thread.likes;
    }

    deleteThread(threadId, requesterEmail) {
        const index = this.data.threads.findIndex(t => String(t.id) === String(threadId));
        if (index === -1) return false;
        
        // Admin or author can delete
        const thread = this.data.threads[index];
        if (requesterEmail && thread.authorEmail !== requesterEmail && requesterEmail !== 'admin@chuyentra.vn') {
            throw new Error('Chỉ tác giả hoặc Quản trị viên mới được xóa bài');
        }

        this.data.threads.splice(index, 1);
        this.save();
        return true;
    }

    // ==========================================
    // ORDERS
    // ==========================================
    getAllOrders(userEmail = null) {
        let list = [...this.data.orders];
        if (userEmail && userEmail !== 'admin@chuyentra.vn') {
            list = list.filter(o => o.userEmail && o.userEmail.toLowerCase() === userEmail.toLowerCase());
        }
        return list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    }

    createOrder(orderData) {
        const orderId = 'DH' + Math.floor(100000 + Math.random() * 900000);
        const newOrder = {
            id: orderId,
            customerName: orderData.customerName,
            customerPhone: orderData.customerPhone,
            customerAddress: orderData.customerAddress,
            notes: orderData.notes || '',
            paymentMethod: orderData.paymentMethod || 'cod',
            items: orderData.items || [],
            total: Number(orderData.total || 0),
            status: 'Chờ duyệt',
            userEmail: orderData.userEmail || '',
            createdAt: Date.now()
        };
        this.data.orders.unshift(newOrder);
        this.save();
        return newOrder;
    }

    updateOrderStatus(orderId, status) {
        const order = this.data.orders.find(o => String(o.id) === String(orderId));
        if (!order) throw new Error('Không tìm thấy đơn hàng');
        order.status = status;
        order.updatedAt = Date.now();
        this.save();
        return order;
    }

    // ==========================================
    // BOOKINGS (ĐẶT LỊCH THƯỞNG TRÀ)
    // ==========================================
    getAllBookings(userEmail = null) {
        let list = [...this.data.bookings];
        if (userEmail && userEmail !== 'admin@chuyentra.vn') {
            list = list.filter(b => b.userEmail && b.userEmail.toLowerCase() === userEmail.toLowerCase());
        }
        return list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    }

    createBooking(bookingData) {
        const bookingId = 'BK' + Math.floor(10000 + Math.random() * 90000);
        const newBooking = {
            id: bookingId,
            name: bookingData.name,
            phone: bookingData.phone,
            date: bookingData.date,
            timeSlot: bookingData.timeSlot,
            note: bookingData.note || '',
            contactType: bookingData.contactType || 'Đặt lịch ghé Trà Thất',
            userEmail: bookingData.userEmail || 'guest@chuyentra.vn',
            status: 'Chờ xác nhận',
            createdAt: Date.now()
        };
        this.data.bookings.unshift(newBooking);
        this.save();
        return newBooking;
    }

    updateBookingStatus(bookingId, status) {
        const booking = this.data.bookings.find(b => String(b.id) === String(bookingId));
        if (!booking) throw new Error('Không tìm thấy lịch hẹn');
        booking.status = status;
        booking.updatedAt = Date.now();
        this.save();
        return booking;
    }

    // ==========================================
    // NEWSLETTER
    // ==========================================
    addNewsletter(email) {
        const clean = email.trim().toLowerCase();
        if (!this.data.newsletter.some(n => n.email === clean)) {
            this.data.newsletter.push({
                id: 'nl_' + Date.now(),
                email: clean,
                createdAt: Date.now()
            });
            this.save();
        }
        return true;
    }

    // ==========================================
    // STATS & ADMIN OVERVIEW
    // ==========================================
    getStats() {
        const totalRevenue = this.data.orders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
        return {
            usersCount: this.data.users.length,
            threadsCount: this.data.threads.length,
            ordersCount: this.data.orders.length,
            bookingsCount: this.data.bookings.length,
            totalRevenue,
            dbPath: DB_FILE,
            serverTime: new Date().toISOString()
        };
    }
}

const db = new Database();
module.exports = db;
