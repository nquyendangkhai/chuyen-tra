/**
 * server.js — Máy chủ Backend REST API & Database cho Chuyện Trà
 * Node.js + Express + JSON Database Engine
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Serve frontend static files
app.use(express.static(path.join(__dirname, 'public')));

// =========================================================================
// API ROUTES
// =========================================================================

// 1. Hệ thống & Thống kê
app.get('/api/status', (req, res) => {
    try {
        const stats = db.getStats();
        res.json({
            success: true,
            status: 'online',
            message: 'Máy chủ Backend & Database Chuyện Trà đang hoạt động hoàn hảo',
            stats
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 2. Quản lý Người dùng & Xác thực (Auth & Users)
app.get('/api/users', (req, res) => {
    try {
        const users = db.getAllUsers();
        res.json({ success: true, users });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/users/:id', (req, res) => {
    try {
        const user = db.findUserById(req.params.id);
        if (!user) return res.status(404).json({ success: false, error: 'Không tìm thấy người dùng' });
        const { passwordHash: _, ...safeUser } = user;
        res.json({ success: true, user: safeUser });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/auth/register', (req, res) => {
    try {
        const { name, email, badge, password, phone, address, role } = req.body;
        if (!name || !email) {
            return res.status(400).json({ success: false, error: 'Họ tên và email là bắt buộc' });
        }
        const user = db.createUser({ name, email, badge, password, phone, address, role });
        res.status(201).json({
            success: true,
            message: 'Đăng ký tài khoản thành công',
            user
        });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

app.post('/api/auth/login', (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email) {
            return res.status(400).json({ success: false, error: 'Vui lòng nhập email' });
        }
        
        let user = null;
        if (!password) {
            // Quick-switch / anonymous login by email
            const existing = db.findUserByEmail(email);
            if (existing) {
                const { passwordHash: _, ...safeUser } = existing;
                user = safeUser;
            } else {
                // Auto create guest/user account
                user = db.createUser({
                    name: 'Trà hữu ' + email.split('@')[0],
                    email: email,
                    badge: 'Trà Hữu Tri Âm',
                    password: 'default_password'
                });
            }
        } else {
            user = db.verifyUser(email, password);
            if (!user) {
                return res.status(401).json({ success: false, error: 'Email hoặc mật khẩu không chính xác' });
            }
        }

        res.json({
            success: true,
            message: 'Đăng nhập thành công',
            user
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.put('/api/users/:id', (req, res) => {
    try {
        const updated = db.updateUser(req.params.id, req.body);
        res.json({ success: true, message: 'Cập nhật thông tin thành công', user: updated });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

app.delete('/api/users/:id', (req, res) => {
    try {
        const deleted = db.deleteUser(req.params.id);
        if (!deleted) return res.status(404).json({ success: false, error: 'Người dùng không tồn tại' });
        res.json({ success: true, message: 'Đã xóa người dùng' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 3. Diễn đàn (Forum Threads & Comments)
app.get('/api/forum/threads', (req, res) => {
    try {
        const category = req.query.category || 'all';
        const threads = db.getAllThreads(category);
        res.json({ success: true, threads });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/forum/threads/:id', (req, res) => {
    try {
        const thread = db.getThreadById(req.params.id);
        if (!thread) return res.status(404).json({ success: false, error: 'Không tìm thấy bài viết' });
        res.json({ success: true, thread });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/forum/threads', (req, res) => {
    try {
        const { title, category, content, authorName, authorEmail, authorBadge } = req.body;
        if (!title || !content) {
            return res.status(400).json({ success: false, error: 'Tiêu đề và nội dung bài viết không được để trống' });
        }
        const newThread = db.createThread({ title, category, content, authorName, authorEmail, authorBadge });
        res.status(201).json({ success: true, message: 'Đăng bài thảo luận thành công', thread: newThread });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

app.post('/api/forum/threads/:id/replies', (req, res) => {
    try {
        const { authorName, authorEmail, authorBadge, content } = req.body;
        if (!content) {
            return res.status(400).json({ success: false, error: 'Nội dung phản hồi không được để trống' });
        }
        const result = db.addReply(req.params.id, { authorName, authorEmail, authorBadge, content });
        res.status(201).json({ success: true, message: 'Đã thêm phản hồi', data: result });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

app.post('/api/forum/threads/:id/like', (req, res) => {
    try {
        const likes = db.toggleLike(req.params.id);
        res.json({ success: true, likes });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

app.delete('/api/forum/threads/:id', (req, res) => {
    try {
        const requesterEmail = req.query.email || req.body.email || '';
        const deleted = db.deleteThread(req.params.id, requesterEmail);
        if (!deleted) return res.status(404).json({ success: false, error: 'Không tìm thấy bài viết' });
        res.json({ success: true, message: 'Đã xóa bài viết' });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

// 4. Đơn hàng (Orders)
app.get('/api/orders', (req, res) => {
    try {
        const userEmail = req.query.email || null;
        const orders = db.getAllOrders(userEmail);
        res.json({ success: true, orders });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/orders', (req, res) => {
    try {
        const orderData = req.body;
        if (!orderData.customerName || !orderData.customerPhone || !orderData.items || orderData.items.length === 0) {
            return res.status(400).json({ success: false, error: 'Thông tin người nhận và giỏ hàng không được để trống' });
        }
        const order = db.createOrder(orderData);
        res.status(201).json({ success: true, message: 'Đặt hàng thành công', order });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

app.put('/api/orders/:id/status', (req, res) => {
    try {
        const { status } = req.body;
        if (!status) return res.status(400).json({ success: false, error: 'Trạng thái đơn hàng là bắt buộc' });
        const order = db.updateOrderStatus(req.params.id, status);
        res.json({ success: true, message: 'Cập nhật trạng thái đơn hàng thành công', order });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

// 5. Đặt lịch thưởng trà (Bookings)
app.get('/api/bookings', (req, res) => {
    try {
        const userEmail = req.query.email || null;
        const bookings = db.getAllBookings(userEmail);
        res.json({ success: true, bookings });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/bookings', (req, res) => {
    try {
        const bookingData = req.body;
        if (!bookingData.name || !bookingData.phone || !bookingData.date || !bookingData.timeSlot) {
            return res.status(400).json({ success: false, error: 'Vui lòng điền đủ tên, số điện thoại, ngày và giờ hẹn' });
        }
        const booking = db.createBooking(bookingData);
        res.status(201).json({ success: true, message: 'Đặt lịch thành công', booking });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

app.put('/api/bookings/:id/status', (req, res) => {
    try {
        const { status } = req.body;
        const booking = db.updateBookingStatus(req.params.id, status);
        res.json({ success: true, message: 'Cập nhật trạng thái lịch hẹn thành công', booking });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

// 6. Bản tin Newsletter
app.post('/api/newsletter', (req, res) => {
    try {
        const { email } = req.body;
        if (!email) return res.status(400).json({ success: false, error: 'Email không hợp lệ' });
        db.addNewsletter(email);
        res.json({ success: true, message: 'Đăng ký nhận bản tin Chuyện Trà thành công' });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

// Admin Route alias
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Fallback to index.html for client-side routing
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
    console.log('\n======================================================');
    console.log(`🍵 MÁY CHỦ BACKEND & DATABASE CHUYỆN TRÀ ĐANG CHẠY!`);
    console.log(`📡 Cổng dịch vụ (Port): ${PORT}`);
    console.log(`🌐 Website Frontend:     http://localhost:${PORT}`);
    console.log(`👑 Trang Quản Trị Admin: http://localhost:${PORT}/admin`);
    console.log(`📊 API Kiểm Tra DB:     http://localhost:${PORT}/api/status`);
    console.log(`💾 Tệp Lưu Trữ Database: ${path.join(__dirname, 'data', 'database.json')}`);
    console.log('======================================================\n');
});
