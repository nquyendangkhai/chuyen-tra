@echo off
chcp 65001 > nul
echo ========================================================
echo   🌐 TẠO ĐƯỜNG LINK PUBLIC CHO WEBSITE CHUYỆN TRÀ
echo ========================================================
echo.
echo Đang tạo đường dẫn internet an toàn (HTTPS) qua LocalTunnel...
echo Vui lòng đợi trong giây lát...
echo.
npx localtunnel --port 5000
pause
