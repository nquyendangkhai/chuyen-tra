@echo off
chcp 65001 > nul
echo ========================================================
echo   🍵 KHỞI ĐỘNG HỆ THỐNG BACKEND & DATABASE CHUYỆN TRÀ
echo ========================================================
echo.
cd /d "%~dp0"
node server.js
pause
